from enum import Enum


class TargetPlatform(Enum):
    WAREHOUSE = "warehouse"
    SNOWPARK_CONTAINER_SERVICES = "SNOWPARK_CONTAINER_SERVICES"
