import gc
import logging
import os
import tempfile
from enum import Enum
from typing import Any, Dict, List, Optional, Protocol, Tuple

import pandas as pd
import torch
from datasets import Dataset, IterableDataset
from peft import (
    AutoPeftModelForCausalLM,
    LoraConfig,
    PeftConfig,
    PeftModel,
    TaskType,
    get_peft_model,
    prepare_model_for_kbit_training,
)
from pydantic import BaseModel
from transformers import (
    AutoConfig,
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
    DataCollatorForSeq2Seq,
    PreTrainedTokenizerBase,
    Trainer,
    TrainingArguments,
)
from vllm import LLM, SamplingParams

logger = logging.getLogger(__name__)


class QuantizationConfig(BaseModel):
    k_bits: int
    llm_int8_threshold: float = 6.0
    llm_int8_has_fp16_weight: bool = False
    bnb_4bit_compute_dtype: str = "bfloat16"  # or float32, bfloat16
    bnb_4bit_use_double_quant: bool = True
    bnb_4bit_quant_type: str = "nf4"  # or fp4


class ModelConfig(BaseModel):
    # Lora params
    lora_r: int = 8
    lora_alpha: int = 16
    lora_dropout: int = 0.05
    lora_target_modules: List[str] = ["q_proj", "v_proj"]
    # General Trainer
    micro_batch_size: int = 1
    gradient_accumulation_steps: int = 4
    optimizer: str = "adamw_torch_fused"
    lr_scheduler: str = "cosine"
    learning_rate: float = 2e-4
    num_epochs: int = 1
    max_steps: int = -1
    compute_dtype = "bfloat16"  # or float16
    gradient_checkpointing: bool = True
    logging_steps: int = 10
    eval_steps: int = 10
    warmup_steps: int = 50
    quantization: Optional[QuantizationConfig] = None
    # Sample input & output
    custom_system_message: Optional[str] = None
    # System setting
    merged_weights_dir_path: Optional[str] = (None,)


class GenerationConfig(BaseModel):
    temperature: float = 0.01
    top_p: float = 1.0
    max_tokens: int = 100


_DEFAULT_SYSTEM_MESSAGE = (
    "Below is an instruction that describes a task, "
    "paired with an input that provides further context. "
    "Write a response that appropriately completes the request."
)


class PromptGen(Protocol):
    def validate_df(self, df: pd.DataFrame) -> None:
        pass

    def validate_sample_for_infer(self, sample: Dict[str, Any]) -> None:
        pass

    def get_prompt(self, sample: Dict[str, Any]) -> str:
        pass

    def get_prompt_template(self) -> str:
        pass

    def update_system_message(self, new_sys_message) -> None:
        pass


class _Llama2ChatInstructPromptGen:
    def __init__(self, system_message: Optional[str] = None) -> None:
        if not system_message:
            system_message = _DEFAULT_SYSTEM_MESSAGE
        self.system_message = system_message

    def validate_df(self, df: pd.DataFrame):
        if "input" not in df or "instruction" not in df or "output" not in df:
            raise ValueError("'input', 'instruction', 'output' columns are required  for llama2 instruct.")

    def validate_sample_for_infer(self, sample: Dict[str, Any]):
        if "input" not in sample or "instruction" not in sample:
            raise ValueError("'input', 'instruction' columns are required  for llama2 instruct inference.")

    def get_prompt_template(self) -> str:
        system_template = f"<<SYS>>\n{self.system_message}\n<</SYS>>\n"
        turn_format = "### Instruction:\n{instruction}\n### Input:\n{input}\n"
        return f"[INST]{system_template}{turn_format}[/INST]\n"

    def get_prompt(self, sample: Dict[str, Any]) -> str:
        instruction = sample["instruction"]
        input = sample["input"]
        template = self.get_prompt_template()
        full_message = template.format(
            instruction=instruction,
            input=input,
        )
        return full_message

    def update_system_message(self, new_sys_message) -> None:
        self.system_message = new_sys_message


class _InstructTokenizationHelper:
    """Helper to generate fully tokenized (prompt, label) for given sample."""

    def __init__(self, tokenizer, prompt_gen) -> None:
        self._tokenizer = tokenizer
        self._max_length = tokenizer.model_max_length
        self._prompt_gen = prompt_gen

    def _instruct_prompt(self, sample) -> str:
        return self._prompt_gen.get_prompt(sample)

    def _tokenize(
        self,
        prompt: str,
        add_eos_token: bool = True,
        strip_bos_token: bool = False,
    ) -> PreTrainedTokenizerBase:
        result = self._tokenizer(
            prompt,
            truncation=True,
            max_length=self._max_length,
            padding=False,
            return_tensors=None,
        )
        if (
            len(result["input_ids"]) > 0
            and result["input_ids"][-1] != self._tokenizer.eos_token_id
            and len(result["input_ids"]) < self._max_length
            and add_eos_token
        ):
            result["input_ids"].append(self._tokenizer.eos_token_id)
            result["attention_mask"].append(1)

        if len(result["input_ids"]) > 0 and result["input_ids"][0] == self._tokenizer.bos_token_id and strip_bos_token:
            result["input_ids"] = result["input_ids"][1:]
            result["attention_mask"] = result["attention_mask"][1:]

        result["labels"] = result["input_ids"].copy()

        return result

    def tokenize_input_output(self, sample):
        ip = self._instruct_prompt(sample)
        tokenized_prompt = self._tokenize(ip, add_eos_token=False)
        ip_len = len(tokenized_prompt["input_ids"])
        # -100 to exclude from loss calculation.
        tokenized_prompt["labels"] = [-100] * ip_len
        tokenized_res_prompt = self._tokenize(
            sample["output"],
            strip_bos_token=True,
            add_eos_token=True,
        )
        tokenized_prompt["input_ids"] += tokenized_res_prompt["input_ids"]
        tokenized_prompt["attention_mask"] += tokenized_res_prompt["attention_mask"]
        tokenized_prompt["labels"] += tokenized_res_prompt["input_ids"]
        return tokenized_prompt


class _TokenizedDataset(Dataset):
    """A lazy dataset containing only tokenzied features for trainer."""

    def __init__(
        self,
        prompt_helper: _InstructTokenizationHelper,
        dataset: IterableDataset,
    ) -> None:
        self._prompt_helper = prompt_helper
        super().__init__(self.process(dataset).data)

    def process(self, dataset: Dataset):
        features = dataset.features.keys()
        num_proc = min(64, os.cpu_count())
        return dataset.map(
            self._prompt_helper.tokenize_input_output,
            num_proc=num_proc,
            remove_columns=features,
        )


def _load_model(model_id: str, mcfg: Dict[str, Any]):
    peft_config = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        inference_mode=False,
        r=mcfg.lora_r,
        lora_alpha=mcfg.lora_alpha,
        lora_dropout=mcfg.lora_dropout,
        target_modules=mcfg.lora_target_modules,
    )
    model_kwargs = dict()
    if mcfg.quantization:
        qcfg = mcfg.quantization
        logger.info(f"Running in quantization mode with {qcfg.k_bits} bits.")
        compute_dtype = getattr(torch, qcfg.bnb_4bit_compute_dtype)
        cfg = BitsAndBytesConfig(
            load_in_4bit=qcfg.k_bits == 4,
            load_in_8bit=qcfg.k_bits == 8,
            llm_int8_threshold=qcfg.llm_int8_threshold,
            llm_int8_has_fp16_weight=qcfg.llm_int8_has_fp16_weight,
            bnb_4bit_compute_dtype=qcfg.bnb_4bit_compute_dtype,
            bnb_4bit_use_double_quant=qcfg.bnb_4bit_use_double_quant,
            bnb_4bit_quant_type=qcfg.bnb_4bit_quant_type,
        )
        model_kwargs["quantization_config"] = cfg
        # For quantization, focus on single GPU
        model_kwargs["device_map"] = {"": 0}
        model_kwargs["torch_dtype"] = compute_dtype
        model = AutoModelForCausalLM.from_pretrained(
            model_id,
            trust_remote_code=True,
            **model_kwargs,
        )
        prepare_model_for_kbit_training(
            model,
            use_gradient_checkpointing=mcfg.gradient_checkpointing,
        )
    else:
        model_kwargs["device_map"] = "auto"
        model = AutoModelForCausalLM.from_pretrained(
            model_id,
            trust_remote_code=True,
            **model_kwargs,
        )
        model.enable_input_require_grads()
    model.tie_weights()
    model = get_peft_model(model, peft_config)
    model.print_trainable_parameters()
    return model


def _load_tokenizer(
    model_id: str,
    model_max_length: int = 4096,
) -> PreTrainedTokenizerBase:
    tokenizer = AutoTokenizer.from_pretrained(
        model_id,
        padding_side="right",
        use_fast=False,
    )
    tokenizer.model_max_length = model_max_length
    tokenizer.pad_token = tokenizer.eos_token
    return tokenizer


def _load_tokenized_instruct_dataset_from_dataset(
    dataset,
    tokenizer,
    prompt_gen,
) -> Dataset:
    prompt_helper = _InstructTokenizationHelper(tokenizer, prompt_gen)
    tpd = _TokenizedDataset(prompt_helper, dataset)
    return tpd


def _memory_stats(msg: str) -> None:
    logger.info(msg)
    logger.info(f"Torch VRAM {torch.cuda.memory_allocated()/1024**2} MB allocated.")
    logger.info(f"Torch VRAM {torch.cuda.memory_reserved()/1024**2} MB reserved.")


def merge_weights_for_lora(lora_dir: str, target_dir: str) -> None:
    """Utility function to convert finetune weights to full merged model weights.

    Args:
        lora_dir(str): Dir path containing only the LORA weights.
        target_dir(str): Dir path where merged weights will be written.
            Content will be overwritten.
    """
    peft_config = PeftConfig.from_pretrained(lora_dir)
    base_model_path = peft_config.base_model_name_or_path
    tokenizer = AutoTokenizer.from_pretrained(
        base_model_path,
        padding_side="right",
    )
    if not tokenizer.pad_token:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.save_pretrained(target_dir)
    hf_model = AutoPeftModelForCausalLM.from_pretrained(
        lora_dir,
        device_map="auto",
        torch_dtype="auto",
    )
    hf_model.eval()
    hf_model = hf_model.merge_and_unload()
    hf_model.save_pretrained(target_dir)
    del tokenizer
    del hf_model
    gc.collect()
    torch.cuda.empty_cache()
    _memory_stats("After weights merge and unload.")


class FinetuneTaskType(Enum):
    """Enum of all the supported finetune tasks.

    Currently, only INSTRUCT is supported.
    """

    INSTRUCT = "INSTRUCT"
    """Represent QA style task, where each sample contains 'instruction' and 'input".
    And, model is prompted to predict 'output'
    """


class FinetuneModelRunner:
    _LLAMA2_MODEL_TYPE = "llama"
    _PROMPT_MAPPING: Dict[Tuple[str, FinetuneTaskType], PromptGen] = {
        (_LLAMA2_MODEL_TYPE, FinetuneTaskType.INSTRUCT): _Llama2ChatInstructPromptGen,
    }

    class _RunnerState(Enum):
        INIT = 0
        TRAIN = 1
        # When merged model is loaded by infer_engine
        EVAL = 2

    @classmethod
    def from_merged_for_eval(
        cls, *, base_model_id: str, path: str, eval_dataset: pd.DataFrame
    ) -> "FinetuneModelRunner":
        """Load fully merged model weights for local inference.

        Args:
            base_model_id(str): Base model id.
            path(str): Dir path for fully merged model weights.
            eval_dataset(datasets.Dataset): eval dataset.

        Returns:
            a runner
        """
        runner = FinetuneModelRunner(
            model_id=base_model_id,
            task_type=FinetuneTaskType.INSTRUCT,
            eval_dataset=eval_dataset,
            merged_model_dir=path,
        )
        return runner

    def _validate_model_id(self, base_model_id):
        if os.path.isdir(base_model_id) or os.path.isfile(base_model_id):
            raise ValueError("Only remove huggingface model_id is supported for now.")
        model_config = AutoConfig.from_pretrained(
            base_model_id,
        )
        if model_config.model_type != FinetuneModelRunner._LLAMA2_MODEL_TYPE:
            raise ValueError("Currently only llama model is supported.")
        self.base_model_id = base_model_id
        self.model_type = FinetuneModelRunner._LLAMA2_MODEL_TYPE

    def __init__(
        self,
        *,
        base_model_id: str,
        task_type: FinetuneTaskType,
        train_dataset: Optional[pd.DataFrame] = None,
        eval_dataset: Optional[pd.DataFrame] = None,
        merged_model_dir: Optional[str] = None,
    ) -> None:
        self._validate_model_id(base_model_id)
        assert task_type == FinetuneTaskType.INSTRUCT, "Currently only instruct type is supported."
        self._task_type = task_type
        self.prompt_gen = _Llama2ChatInstructPromptGen()
        self.train_dataset = train_dataset
        self.eval_dataset = eval_dataset
        if merged_model_dir:
            self.merged_dir = merged_model_dir
            self._load_inference_engine(self.merged_dir)
            self._state = self._RunnerState.EVAL
        else:
            self._state = self._RunnerState.TRAIN

    @property
    def train_dataset(self) -> Optional[pd.DataFrame]:
        return self._train_dataset

    @property
    def eval_dataset(self) -> Optional[pd.DataFrame]:
        return self._eval_dataset

    @train_dataset.setter
    def train_dataset(self, df: pd.DataFrame) -> None:
        self.prompt_gen.validate_df(df)
        self._train_dataset = df

    @eval_dataset.setter
    def eval_dataset(self, df: pd.DataFrame) -> None:
        self.prompt_gen.validate_df(df)
        self._eval_dataset = df

    def _transition_to_train_state(self) -> None:
        if self._state == self._RunnerState.EVAL:
            del self.infer_engine
            gc.collect()
            torch.cuda.empty_cache()
            _memory_stats("After removing the local inference engine.")
        self._state = self._RunnerState.TRAIN

    def train(self, output_dir: str, *, model_cfg: Optional[ModelConfig] = None):
        """Kick off a training run.

        Args:
            output_dir(str): Dir path to overwrite with trained model weights.
            model_cfg(ModelConfig): `ModelConfig` to adjust finetune.

        Raises:
            ValueError: if either `train_dataset` or `eval_dataset` is not set.

        Returns:
            training output.
        """
        self._transition_to_train_state()
        if self.train_dataset is None or self.eval_dataset is None:
            raise ValueError("Both train and eval dataset has to be set to start training.")
        # TODO(halu): Basic validation on model config
        if not model_cfg:
            model_cfg = ModelConfig()
        if model_cfg.custom_system_message:
            self.prompt_gen.update_system_message()
        tokenizer = _load_tokenizer(model_id=self.base_model_id)
        model = _load_model(model_id=self.base_model_id, mcfg=model_cfg)
        self.output_dir = output_dir
        if not model_cfg.merged_weights_dir_path:
            self.merged_dir_holder = tempfile.TemporaryDirectory()
            self.merged_dir = self.merged_dir_hodler.name
        else:
            assert os.path.isdir(model_cfg.merged_weights_dir_path), "Must be an directory to store merged weights."
            self.merged_dir = model_cfg.merged_weights_dir_path
        training_arguments = TrainingArguments(
            output_dir=output_dir,
            overwrite_output_dir=True,
            per_device_train_batch_size=model_cfg.micro_batch_size,
            gradient_accumulation_steps=model_cfg.gradient_accumulation_steps,
            optim=model_cfg.optimizer,
            lr_scheduler_type=model_cfg.lr_scheduler,
            logging_steps=model_cfg.logging_steps,
            learning_rate=model_cfg.learning_rate,
            bf16=model_cfg.compute_dtype == "bfloat16",
            fp16=model_cfg.compute_dtype == "float16",
            num_train_epochs=model_cfg.num_epochs,
            gradient_checkpointing=model_cfg.gradient_checkpointing,
            warmup_steps=model_cfg.warmup_steps,
            evaluation_strategy="steps",
            eval_steps=model_cfg.eval_steps,
            max_steps=model_cfg.max_steps,
        )
        train_ds = _load_tokenized_instruct_dataset_from_dataset(
            Dataset.from_pandas(self.train_dataset),
            tokenizer,
            self.prompt_gen,
        )
        eval_ds = _load_tokenized_instruct_dataset_from_dataset(
            Dataset.from_pandas(self.eval_dataset),
            tokenizer,
            self.prompt_gen,
        )
        trainer = Trainer(
            model=model,
            train_dataset=train_ds,
            eval_dataset=eval_ds,
            args=training_arguments,
            data_collator=DataCollatorForSeq2Seq(
                tokenizer,
                return_tensors="pt",
                padding=True,
            ),
        )
        model.config.use_cache = False
        trainer_output = trainer.train()
        trainer.save_model()
        del trainer
        del tokenizer
        model.eval()
        del model
        gc.collect()
        torch.cuda.empty_cache()
        _memory_stats("After clearing model state after training.")
        self._merge_weights_for_eval(self.merged_dir)
        self._load_inference_engine(self.merged_dir)
        self._state = FinetuneModelRunner._RunnerState.EVAL

        return trainer_output

    def _merge_weights_for_eval(self, path: str) -> None:
        """Merge LORA and base weights to save and re-load for inference.

        Args:
            path(str): Dir path to save the merged model weights.
        """
        tokenizer = _load_tokenizer(model_id=self.base_model_id)
        tokenizer.save_pretrained(path)
        model = AutoModelForCausalLM.from_pretrained(
            self.base_model_id,
            torch_dtype=torch.bfloat16,
            device_map="auto",
        )
        model = PeftModel.from_pretrained(model, self.output_dir)
        model = model.merge_and_unload()
        model.save_pretrained(path)
        del model
        gc.collect()
        torch.cuda.empty_cache()
        _memory_stats("After the model weights merge.")

    def _load_inference_engine(self, path) -> None:
        # device_count = torch.cuda.device_count()
        # TODO(halu): Enforce single GPU for local inference
        # to make VRAM cleanup cleaner.
        self.infer_engine = LLM(model=path, tensor_parallel_size=1)

    def get_eval_results(self, generation_config: Optional[GenerationConfig] = None) -> pd.DataFrame:
        """Run against entire evaluation dataset for manual inspection.

        Args:
            generation_config(GenerationConfig): `GenerationConfig` for controlling generation.

        Returns:
            A pandas dataframe with 'predicted' column containing the prediction results.

        Raises:
            ValueError: if `eval_dataset` is not set.
        """
        self._ensure_eval_mode()
        if self.eval_dataset is None:
            raise ValueError("Eval dataset is not set.")
        if not generation_config:
            generation_config = GenerationConfig()
        sampling_params = SamplingParams(
            temperature=generation_config.temperature,
            top_p=generation_config.top_p,
            max_tokens=generation_config.max_tokens,
        )
        eval_df = self.eval_dataset

        def gen_prompt(row):
            prompt = self.prompt_gen.get_prompt(row)
            return prompt

        prompts = eval_df.apply(gen_prompt, axis=1).to_list()
        res = self.infer_engine.generate(prompts, sampling_params)
        ts = [o.outputs[0].text for o in res]
        eval_df["predicted"] = ts
        return eval_df

    def infer(
        self,
        sample: Dict[str, Any],
        generation_config: Optional[GenerationConfig] = None,
    ) -> str:
        """Run a single sample against model locally.

        Args:
            sample(dict): A dict contains all the keys for the given task.
            generation_config(dict): `GenerationConfig` for controlling generation.

        Returns:
            A single string for generation.
        """
        self._ensure_eval_mode()
        self.prompt_gen.validate_sample_for_infer(sample)
        if not generation_config:
            generation_config = GenerationConfig()
        sampling_params = SamplingParams(
            temperature=generation_config.temperature,
            top_p=generation_config.top_p,
            max_tokens=generation_config.max_tokens,
        )
        prompt = self.prompt_gen.get_prompt(sample)
        res = self.infer_engine.generate([prompt], sampling_params)
        t = res[0].outputs[0].text
        return t

    def _ensure_eval_mode(self) -> None:
        if self._state != FinetuneModelRunner._RunnerState.EVAL:
            raise ValueError("`train` needs to be done first for evaluation/inference.")

    def infer_batch(
        self,
        df: pd.DataFrame,
        generation_config: Optional[GenerationConfig] = None,
    ) -> pd.DataFrame:
        """Run local batch inference against a dataset.

        Args:
            df(pd.Dataframe): A dataset to run.
            generation_config(dict): `GenerationConfig` for controlling generation.

        Returns:
            A pandas dataframe with provided columns and extra 'predicted' column
            containing the predictions.
        """
        self._ensure_eval_mode()
        if not generation_config:
            generation_config = GenerationConfig()
        sampling_params = SamplingParams(
            temperature=generation_config.temperature,
            top_p=generation_config.top_p,
            max_tokens=generation_config.max_tokens,
        )

        def gen_prompt(row: Dict[str, Any]) -> str:
            prompt = self.prompt_gen.get_prompt(row)
            return prompt

        prompts = df.apply(gen_prompt, axis=1).to_list()
        res = self.infer_engine.generate(prompts, sampling_params)
        ts = [o.outputs[0].text for o in res]
        df["predicted"] = ts
        return df
